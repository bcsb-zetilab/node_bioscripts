var Datastore = require('nedb'),
	path = require('path'),
	fs = require('fs'),
	request = require('request'),
	dateformat = require('dateformat'),
	readline = require('readline'),
	LineByLineReader = require('line-by-line'),
	dbs = {};

var tf_output = {};

//Visualization parameters
var colorPalettes = [
	'#4D4D4D', '#5DA5DA', '#FAA43A', 
	'#60BD68', '#F17CB0', '#B2912F',
	'#B276B2', '#DECF3F', '#F15854'
];

dbs.tfdata = new Datastore({
	filename: path.join(require('nw.gui').App.dataPath, 'tfdata.db')
});

dbs.tfdata.loadDatabase();

function checkSourceDB(){
	var custom_biodbs_path = $("#biodbs_path").val();
	var biodbs_path = "";
	if(custom_biodbs_path != undefined){
		if(custom_biodbs_path != ""){
			biodbs_path = custom_biodbs_path;
		}
	}

	if(biodbs_path === ""){
		biodbs_path = path.join(require('nw.gui').App.dataPath, 'biodbs'); 
		if(!fs.existsSync(biodbs_path)){
			fs.mkdirSync(biodbs_path);
		}
	}

	//check if is directory
	try {
    	// Query the entry
    	stats = fs.lstatSync(biodbs_path);

    	// Is it a directory?
    	if (stats.isDirectory()) {
        	// Yes it is
        	var sourceDBs = fs.readdirSync(biodbs_path);
        	console.log(sourceDBs.toString());
    	}
	} catch (e) {
    	console.log("Error: " + e.toString());
	}	
}

function checkDBUpdates()
{
	var chknames = "PlnTFDB,PlantTFDB";
	var apitoken = $("#apitoken").val();
	var apiurl = $("#apiurl").val();
	var formdata = "tdata=1&check[names]=" + encodeURIComponent(chknames);
	formdata += "&token=" + encodeURIComponent(apitoken);

	var options = {
	    url: apiurl + "/software/checkDBUpdates",
	    headers: {
	        'Content-Type': 'application/x-www-form-urlencoded'
	    },
	    body: formdata
	};

	var callback = function callback(error, response, body) {
	    if (!error && response.statusCode == 200) {
	    	var jsondata = $.parseJSON(body);
	    	if(jsondata.response != undefined){
	    		console.log(jsondata.response);
	    		if(jsondata.data != undefined){
	    			var updates;
	    			var tbody_updatelist = "";

	    			//Check local software configs
	    			var localSoftwareConfigPath = path.join(require('nw.gui').App.dataPath, 'softwares.config');
	    			var localSoftwareConfig = "";
	    			var localSoftwareConfigJSON = "";
	    			if(fs.existsSync(localSoftwareConfigPath)){
	    				localSoftwareConfig = fs.readFileSync(localSoftwareConfigPath, 'utf8');
	    				localSoftwareConfigJSON = $.parseJSON(localSoftwareConfig);
	    			}

	    			for(var i=0; i<jsondata.data.length; i++){
	    				//Loop updates...
	    				console.log(JSON.stringify(jsondata.data[i]));

	    				//Skip if already have the version
	    				var softname = jsondata.data[i].software.name;
	    				var softver = jsondata.data[i].version.version;
	    				var softfile = jsondata.data[i].version.downloadName;

	    				var installpath = path.join(require('nw.gui').App.dataPath, '/updates-install/' + softfile)
	    				if(fs.existsSync(installpath)){
	    					continue;
	    				}

	    				/*
	    				if(localSoftwareConfigJSON[softname] != undefined){
	    					if(localSoftwareConfigJSON[softname].version == softver){
	    						continue;
	    					}
	    				}
	    				*/

	    				tbody_updatelist += "<tr>";

	    				tbody_updatelist += "<td>" + jsondata.data[i].software.name + "</td>";

	    				tbody_updatelist += "<td>" + jsondata.data[i].version.version + "</td>";

	    				tbody_updatelist += "<td>" + jsondata.data[i].version.createdAt + "</td>";

	    				tbody_updatelist += "<td align='center'>";
	    				tbody_updatelist += "<div class='checkbox'>";
	    				tbody_updatelist += "<input type='checkbox' name='chkUpdate' class='chkSoftwareUpdate' id='chkUpdate' data-filename='" + jsondata.data[i].version.downloadName + "' data-version='" + jsondata.data[i].version.version + "' value='" + jsondata.data[i].version.downloadUrl + "' />";
						tbody_updatelist += "</div>";
						tbody_updatelist += "</td>";

	    				tbody_updatelist += "</tr>";
	    			}

	    			$("#tbody_updatelist").html(tbody_updatelist);
	    			$("#md-updatesList").modal('show');
	    		}
	    	}
	    } else {
	    	console.log(error);
	    }
	}

	request.post(options, callback);	

	/*
    $.ajax({
        type: "POST",
        url: apiurl + "/software/checkDBUpdates",
        contentType: 'application/x-www-form-urlencoded',
        data: formdata
    }).done(function(res){
    	console.log("aaaaaaaa....");    	
    	console.log(res);
    }).fail(function( jqXHR, textStatus ) {
		console.log( "Request failed: " + textStatus + ", " + status);
	});
	*/

    console.log("Trigger db updates checking...");
}



function terminateApp(){
	require('nw.gui').App.closeAllWindows();
}

function gotoPage(id){
	$(".page").fadeOut();

	//Check if agree
	var firstAccess = $("#firstAccess").val();	
	if(firstAccess != 'true'){
		id = 'main'; //Always show main
		alertify.error('You have not agree to the software agreement.', "", 0);
		setTimeout(function(){
			checkFirstAccess();
		}, 1000);
	}

	$(".sidebar-menu li").each(function(){
		if($(this).data('pageid') == id){
			$(this).addClass('active');

			$(".page-title").html($(this).data('title'));
			var headerText = [
				$(this).data('title'),
				'<small>' + $(this).data('tagline') + '</small>'
			].join("");
			$("#page-title-h1").html(headerText);

		} else{
			$(this).removeClass('active');
		}
	});

	if($("#" + id).html() != undefined){
		setTimeout(function(){
			$("#" + id).fadeIn(500);
			$("#activePage").val(id);			
		}, 800);
	}
}

function gotoUrl(url){
	require('nw.gui').Shell.openExternal(url);
}

function checkFirstAccess()
{
	var firstAccessLog = path.join(require('nw.gui').App.dataPath, 'firstAccess.log');

	if(fs.existsSync(firstAccessLog)){
		var accessData = require('fs').readFileSync(firstAccessLog, 'utf8');

		var accessDataJSON = $.parseJSON(accessData);

		if(accessDataJSON.first != undefined){
			alertify.log('Welcome back ' + accessDataJSON.first.userName + '!');
		} else {
			alertify.log('Welcome back!');
		}

		$("#firstAccess").val('true');

		setTimeout(function(){
			checkSourceDB();
			loadInstalledSoftwares();
		}, 2000);

	} else {
		$("#md-firstAccess").modal('show');
		$("#firstAccess").val('false');
	}
}

function submitFirstAccessForm(){
	var apitoken = $("#apitoken").val();
	var apiurl = $("#apiurl").val();
	var formdata = $("#form-firstAccess").serialize();
	formdata += "&token=" + encodeURIComponent(apitoken);

	var formjson = $("#form-firstAccess").serializeJSON();

    $.ajax({
        type: "POST",
        url: apiurl + "/userdata/appaccess",
        data: formdata
    }).done(function(res){
    	if(res == "OK"){
    		require('fs').writeFileSync(
    			require('path').join(require('nw.gui').App.dataPath, 'firstAccess.log'),
    			JSON.stringify(formjson)
    		);

    		$("#md-firstAccess").modal('hide');
    	} else {
    		console.log(res);
    	}
    });

}

function submitSoftwareUpdates()
{
	var tmpFolder = path.join(require('nw.gui').App.dataPath, '/updates-tmp');
	if(!fs.existsSync(tmpFolder)){
		fs.mkdirSync(tmpFolder);
	}

	if(fs.existsSync(tmpFolder)){

		var counter = 0;
		$(".chkSoftwareUpdate").each(function(){
			if($(this).is(':checked')){

				var filename = $(this).data('filename');
				var filever = $(this).data('version');
				var fileurl = $(this).val();
				console.log("[INFO] Updating..." + filename);

				var installtouch = tmpFolder + "/" + filename + "_" + filever + ".installed";
				fs.writeFileSync(installtouch, new Date().getTime());

				if(fs.existsSync(tmpFolder + "/" + filename)){
					fs.unlinkSync(tmpFolder + "/" + filename); //Clear same named file.	
				}

				setTimeout(function(){
					download(tmpFolder + "/" + filename, fileurl, function(a, file){
						if(fs.existsSync(file)){
							installSoftware(file);
						}
					});
				}, 200 * counter);
			}
			counter++;
		});

	}	
}

function installSoftware(file){
	console.log('[INFO] Installing...' + file);

	var tmpFolder = path.join(require('nw.gui').App.dataPath, '/updates-tmp');
	var installFolder = path.join(require('nw.gui').App.dataPath, '/updates-install');
	if(!fs.existsSync(tmpFolder)){
		fs.mkdirSync(tmpFolder);
	}
	if(!fs.existsSync(installFolder)){
		fs.mkdirSync(installFolder);
	}
	if(fs.existsSync(tmpFolder) && fs.existsSync(installFolder)){
		var filedata = fs.readFileSync(file, 'utf8');
		var lines = filedata.split("\n");
		for(var i=0; i<lines.length; i++){
			var linedata = lines[i].trim();
			console.log(linedata);
			if(linedata != ""){
				var linejson = $.parseJSON(linedata);

				dbs.tfdata.insert(linejson, function (err, newDoc) {
					//TODO?
					console.log(newDoc);
				});
			}
		}
		fs.renameSync(file, file.replace('updates-tmp', 'updates-install'));		
	}
}

function download(localFile, remotePath, callback) {
	var localStream = fs.createWriteStream(localFile);

	var out = request({ uri: remotePath });
	out.on('response', function (resp){
    	if (resp.statusCode === 200){
        	out.pipe(localStream);
        	localStream.on('close', function(){
        		console.log("[INFO] Trigger file download callback.");
            	callback(null, localFile);
        	});
    	} else {
        	callback(new Error("No file found at given url."),null);
    	}
	});

	out.on('error', function (err) {
		console.log('[ERROR] ' + err);
	});
};

function loadInstalledSoftwares()
{
	console.log('[INFO] Checking installed softwares...');
	var tmpFolder = path.join(require('nw.gui').App.dataPath, '/updates-tmp');
	if(!fs.existsSync(tmpFolder)){
		fs.mkdirSync(tmpFolder);
	}
	var tmps = fs.readdirSync(tmpFolder + "/");
	var installedHTML = "";
	for(var i=0; i<tmps.length; i++){
		if(/\.installed/.test(tmps[i])){
			var tmpsdata = tmps[i].split('_');
			if(tmpsdata.length > 1){
				var tmpsname = tmpsdata[0].trim();
				var tmpsver = tmpsdata[1].trim();
				tmpsver = tmpsver.replace('.installed', '');

				var stats = fs.statSync(tmpFolder + "/" + tmps[i]);
				var createdAtTS = dateformat(stats.mtime, "isoDateTime");

				installedHTML += "<tr>";
				installedHTML += "<td>" + tmpsname + "</td>";
				installedHTML += "<td>" + tmpsver + "</td>";
				installedHTML += "<td>" + createdAtTS + "</td>";
				//installedHTML += "<td> - </td>";
				installedHTML += "</tr>";
			}
		}
	}

	if(installedHTML != ""){
		$("#tbody-installed-softwares").html(installedHTML);
	}
}

function triggerInputFileUpload(id)
{
  chooseFile('#' + id);
}

function chooseFile(name) {
	var chooser = $(name);
	chooser.change(function(evt){
		console.log($(this).val());

		var selectedFile = $(this).val();
		if(fs.existsSync(selectedFile)){

			tf_output = {};
			tf_output['hit'] = 0;
			setTFOutput('Processing...<br />' + selectedFile);
			$("#processing-msg").html('');

			setProcessingOnState();

			setTimeout(function(){

				var lr = new LineByLineReader(selectedFile);
				var readedline = 0;

				lr.on('error', function (err) {
				    // 'err' contains error object
				    console.log('[ERROR] ' + err);
				});

				lr.on('line', function (line) {

    				lr.pause();

				    // ...do your asynchronous line processing..
				    setTimeout(function () {

					    // 'line' contains the current line without the trailing newline character.
						console.log('[INFO] Line ' + readedline + " " + line) //or parse line
						var processing_msg = '[INFO] Reading line number ' + readedline;
						processing_msg += '<br /> Found ' + tf_output.hit + ' hits.';
						$("#processing-msg").html(processing_msg);

						var hasHit = false;
						var lineElems = line.split("\t");
						if(lineElems[1] != ""){
							console.log('[INFO] Finding...' + lineElems[1]);
							// "/" + lineElems[1] + "/"
							console.log('[INFO] Find with' + lineElems[1].split('_').toString());
							dbs.tfdata.find({'protein_id' : {'$in' : lineElems[1].split('_')}}, function(err, docs){
								if(docs.length > 0){
									var family = docs[0].family;
									if(family != undefined){
										if(tf_output[family] == undefined){
											tf_output[family] = 1;
										} else {
											tf_output[family]++;
										}								
										hasHit = true;
									}
									tf_output['hit']++;
									console.log('[INFO] FOUND...' + docs.toString() + ".." + docs[0].family);
									console.log(tf_output.hit);
								} else {
									console.log('[INFO] No found for ' + lineElems[1] + ".");
								}
							});

							//Check another...
							//chooseFile('saveFileDialog');

						}
						readedline++;	
				        // ...and continue emitting lines.
				        lr.resume();

				    }, 100);
		    
				});

				lr.on('end', function () {
				    // All lines are read, file is closed now.
					//$("#tf_output").html(tf_output.toString());
					console.log('[INFO] TF analysis Completed!');
					//setTFOutput(JSON.stringify(tf_output));


					setTFOutput('Done.');

					var chartdata = [];
					var colorsCount = colorPalettes.length;
					var dataCounter = 0;

					var outdataStr = "";
					var outdataSeparator = "";
					var remainCount = readedline-1;
					var remainPercentage = 100;

					var tblData = [];

					for(var family in tf_output){

						if(dataCounter > colorsCount - 1){
							dataCounter = 1;
						}

						if(family != 'hit'){
							var familyCount = tf_output[family];
							var familyPercentage = ((tf_output[family] / (readedline-1)) * 100).toFixed(2);
							remainPercentage = remainPercentage - familyPercentage;
							remainCount = remainCount - familyCount;
							chartdata.push(
								{
									value: familyCount,
									color: colorPalettes[dataCounter],
									hightlight: "#FF5A5E",
									label: family
								}
							);

							tblData.push(
								{
									title: family,
									count: familyCount,
									bgcolor: colorPalettes[dataCounter], 
									percentage: familyPercentage
								}
							);

							outdataStr += outdataSeparator + family + "\t" + familyCount + "\t" + familyPercentage;
							outdataSeparator = "\n";
						}
						dataCounter++;
					};

					//Remaining
					outdataStr += "\nNOT FOUND\t" + remainCount + "\t" + ((remainCount / (readedline-1)) * 100).toFixed(2);
					tblData.push(
						{
							title: "NOT FOUND",
							count: remainCount,
							percentage: ((remainCount / (readedline-1)) * 100).toFixed(2)
						}
					);


					//Compile table output
					var tblOutputStr = [
						'<thead>',
							'<tr>',
								'<th>Family Name</th>',
								'<th>Seq Count</th>',
								'<th>Percentage (%)</th>',
							'</tr>',
						'</thead>',
						'<tbody>'
					].join('');
					for(var i=0; i<tblData.length; i++){
						tblOutputStr += [
							'<tr style="background-color: ' + tblData[i].bgcolor + '">',
								'<td>',
									' ' + tblData[i].title + ' ',
									'<a style="color: white;" href="javascript:void(0);" onClick="gotoUrl(\'http://planttfdb.cbi.pku.edu.cn/family.php?fam=' + tblData[i].title + '\');"><i class="fa fa-external"></i> PlantTFDB</a>',
									'<a style="color: white;" href="javascript:void(0);" onClick="gotoUrl(\'http://plntfdb.bio.uni-potsdam.de/v3.0/fam_mem.php?family_id=' + tblData[i].title + '\');"><i class="fa fa-external"></i> PlnTFDB</a>',
								'</td>',
								'<td>' + tblData[i].count + '</td>',
								'<td>' + tblData[i].percentage + '</td>',
							'</tr>'
						].join('');
					}

					tblOutputStr += '</tbody>';

					$("#tblOutput").html(tblOutputStr);


					// Get the context of the canvas element we want to select
					var ctx = document.getElementById("outputChart").getContext("2d");
					var myNewChart = new Chart(ctx).Pie(chartdata);

					setProcessingOffState();

					// Text based output
					//Keep the outdata to parameter
					$("#outdata").val(outdataStr);
					if($("#outdata").val().length > 0){
						saveResult('saveFileDialog');
					}

				});

			}, 500);

/*
			var rl = readline.createInterface({
			      input : fs.createReadStream($(this).val()),
			      output: process.stdout,
			      terminal: false
			});

			rl.on('line',function(line){
				console.log(line) //or parse line
				var hasHit = false;
				var lineElems = line.split("\t");
				if(lineElems[1] != ""){
					console.log('[INFO] Finding...' + lineElems[1]);
					// "/" + lineElems[1] + "/"
					dbs.tfdata.find({'protein_id' : {'$in' : lineElems[1].split('_')}}, function(err, docs){
						if(docs.length > 0){
							var family = docs[0].family;
							if(family != undefined){
								if(tf_output[family] == undefined){
									tf_output[family] = 1;
								} else {
									tf_output[family]++;
								}								
								hasHit = true;
							}
						} else {
							console.log('[INFO] No found for ' + lineElems[1] + ".");
						}
					});

					//Check another...
				}
			});

			rl.on('close', function(){
				//$("#tf_output").html(tf_output.toString());
				console.log('[INFO] TF analysis Completed!');
				setTFOutput(tf_output.toString());
				setProcessingOffState();
			});
*/

		}
	});

	chooser.trigger('click');  
}

function setTFOutput(msg){
	$("#tf_output").html(msg);
}

function setProcessingOnState(){
	$("#md-processing").modal('show');
}

function setProcessingOffState(){
	$("#md-processing").modal('hide');
}

function saveResult(name){
	var chooser = $(name);
	chooser.change(function(evt) {
		var outfile = $(this).val();
		console.log('[INFO] Saving data to ' + $(this).val());
		// Reset the selected value to empty ('')
		$(this).val('');

		var outdata = $("#outdata").val();

		require('fs').writeFileSync(
			require('path').join(outfile),
			outdata
    	);

		alertify.log('Output saved as ' + outfile);
	});

    chooser.trigger('click');  
}














